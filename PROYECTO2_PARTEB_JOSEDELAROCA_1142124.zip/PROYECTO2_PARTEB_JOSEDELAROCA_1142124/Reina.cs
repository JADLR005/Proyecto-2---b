﻿namespace PROYECTO2_PARTEB_JOSEDELAROCA_1142124;

public class Reina : Piezas  //Clase reina con una herencia de la clase Tablero y así poder utilizar todos sus métodos o funciones
{
    //Constructor para Reina
    public Reina(string color, string Tipo = "Reina") : base(Tipo, color)
    {
        Tablero funciones = new Tablero();
    }

    public void IngresarDama()
    {
        

    }

}
