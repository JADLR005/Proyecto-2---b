﻿using System.Runtime.CompilerServices;
using PROYECTO2_PARTEB_JOSEDELAROCA_1142124;

Tablero tablero = new Tablero();
int opcion = 0;
    Console.WriteLine("Bienvenido al Ajedrez :))");    

//Menú interactivo con ciclo do-while
do{
    Console.WriteLine("Elige una de estas opciones disponibles:");
    Console.WriteLine("1. Agregar piezas en el tablero");
    Console.WriteLine("2. Ingresar la dama en el tablero");
    Console.WriteLine("3. Movimientos disponibles");
    Console.WriteLine("4. Imprimir el tablero");
    Console.WriteLine("5. Salir del sistema");
    opcion = int.Parse(Console.ReadLine());    

    switch(opcion)
    {
        case 1: //Solicita la cantidad de piezas que quiere ingresar
                Console.WriteLine("Por favor ingresa la cantidad de piezas que quieres agregar");
                int Npiezas = int.Parse(Console.ReadLine());

                for (int i = 0; i < Npiezas; i++)
                    {
                        Console.WriteLine("Ingrese el tipo de pieza que desea colocar en el tablero; puede ser: (Torre, Alfil, Peón, Caballo o Rey)"); //Solicita el tipo de pieza para agregar 
                        string Tpieza = Console.ReadLine();

                        Console.WriteLine("Ingrese el color de la pieza; puede ser (Blanca o negra)"); //Solicita el color de la pieza para agregar
                        string Cpieza = Console.ReadLine();

                        Console.WriteLine("Por último ingrese la fila de la pieza; puede ser (a1, b1, c1... hasta h8)"); //Solicita la casilla donde la pieza se agregará
                        string Posicion = Console.ReadLine();
                        int f = Posicion[0] - 'a';     //Separamos por datos tipo int la fila y columna y lo igualamos a la posición que es una cadena de texto (string)
                                                       //En la primera letra del string a una referencia de tipo char
                        int c = int.Parse(Posicion[1].ToString()) - 1;  //Hacemos lo mismo en el dato creado tipo int para la columna (Se utiliza ToString para convertirlo a string)
                                                                        //Y luego darle una referencia de tipo string

                        Piezas piezas = new Piezas(Tpieza, Cpieza);     //Objeto o instancia para poder utilizar los métodos de la clase Piezas
                        Console.WriteLine("");                          //Y darle como parámetro los datos solicitados
                        tablero.AgregarPiezas(piezas, f, c);
                    }
                    Console.WriteLine("Piezas agregadas"); break;
            case 2: //Solicita los datos para poder ingresar a la reina en el tablero
                        bool reina1 = tablero.ValidarDama();
                        string ColorR = "";
                        string PosiR = "";
                        Reina reina;
                        int fil = 0;
                        int col = 0;
                        int opcionR = 0;
                        if (reina1 == false)
                        {
                            Console.WriteLine("Ingrese el color de la Reina");
                            ColorR = Console.ReadLine();
                            reina = new Reina(ColorR);
                            Console.WriteLine("Ingrese la posición de la Reina; puede ser (a1, b1... hasta h8)");
                            PosiR = Console.ReadLine();
                            fil = PosiR[0] - 'a';
                            col = int.Parse(PosiR[1].ToString()) - 1;
                            tablero.AgregarReina(reina, fil, col);
                            Console.WriteLine("");
                            Console.WriteLine("¿Quieres imprimir los movimientos de la dama?");
                            Console.WriteLine("Escibe 1 para imprimir y 2 para salir");
                            opcionR = int.Parse(Console.ReadLine());
                            switch (opcionR)
                            {
                                case 1: tablero.MoverseReina(fil, col);
                                break;
                                case 2: 
                                break;
                            }
                            
                        }
                    break;
            case 3: //Despliega un listado de los movimientos posibles que la reina puede realizar
                    Console.WriteLine("Funcionalidad agregada en el case anterior a este");
                    break;
            case 4: //Imprime la matriz creada
                        tablero.ImprimirTablero();
                    break;           
    }
}while(opcion != 5);