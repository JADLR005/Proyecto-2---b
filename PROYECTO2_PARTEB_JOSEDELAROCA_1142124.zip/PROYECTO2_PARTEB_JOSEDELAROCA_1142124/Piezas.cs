﻿namespace PROYECTO2_PARTEB_JOSEDELAROCA_1142124;

public class Piezas
{
    //Parámetros para la clase Piezas
    public string Tipo { get; set; }    
    public string Color { get; set; } 
    
    //Constructor para inicializar los parámetros
    public Piezas (string Tipo, string Color)   
    {
        this.Tipo = Tipo;
        this.Color = Color;
    }


}
