﻿using System.Globalization;

namespace PROYECTO2_PARTEB_JOSEDELAROCA_1142124;

public class Tablero
{
    //Atributos
    public Piezas[,] tablero;   //Como atributo una matriz de dos dimensiones con el nombre de tablero

    //Constructor para inicializar la matriz 
    public Tablero()
    {
        tablero = new Piezas[8,8];  //Igualamos la matriz de Piezas a una matriz de dos dimensiones 8x8
    }

    //Métodos para todo el funcionamiento del tablero a continuación:

    //Método que agrega piezas al tablero según la posición y valida si la posición existe o si hay una pieza ocupando cierta posición
    public bool AgregarPiezas(Piezas pieza, int f, int c)
    {
        if (f < 0 && f >= 8 || c < 0 && c >= 8)     //Realizamos una condición para que valide que la posición esté dentro del rango de la matriz
        {
            Console.WriteLine("La posición que eligió no está en el tablero");
            return false;
        }
        if (tablero[f,c] != null)  //Realizamos otra condición para que valide que si en cualquiera de la posición ingresada, no hay un dato nulo (no está vacío)
                                   //Entonces que no se pueda ingrear la pieza 
        {
            Console.WriteLine("NO se puede colocar, aquí ya hay una pieza");
            return false;
        }
        tablero[f,c] = pieza;   
        return true;
    }

    //Método que imprime el tablero 
    public void ImprimirTablero()
    {
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                if (tablero[i,j] != null)    
                {
                    Console.Write($"{tablero[i,j].Tipo[0]}-{tablero[i,j].Color[0]}");
                }else{
                    Console.Write("[] ");
                }
            }
            Console.WriteLine();
        }
    }

    //Método para la validación de la Reina
    public bool AgregarReina(Piezas pieza, int fil, int col)
    {
        if (pieza.Tipo == "Reina")
        {
            Console.WriteLine("Ya hay una Reina en el tablero");
        }
        if (fil < 0 && fil >= 8 || col < 0 && col >= 8)     //Realizamos una condición para que valide que la posición esté dentro del rango de la matriz
        {
            Console.WriteLine("La posición que eligió no está en el tablero");
            return false;
        }
        if (tablero[fil,col] != null)  //Realizamos otra condición para que valide que si en cualquiera de la posición ingresada, no hay un dato nulo (no está vacío)
                                   //Entonces que no se pueda ingrear la pieza 
        {
            Console.WriteLine("NO se puede colocar, aquí ya hay una pieza");
            return false;
        }
        tablero[fil,col] = pieza;
        return true;
    }

    public bool ValidarDama()
    {
        for (int i = 0; i < tablero.GetLength(0); i++)
        {
            for (int j = 0; j < tablero.GetLength(1); j++)
            {
                if (tablero[i,j] != null && tablero[i,j].Tipo != null)
                {
                    if (tablero[i,j].Tipo == "Reina")
                    {
                        Console.WriteLine("Ya hay una Reina en el tablero");
                        return true;
                    }
                }
                
            }
        }
        return false;
    }
    
    public void MoverseReina(int fil, int col)
    {
        string color = tablero[fil, col].Color;

        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
                if (i == 0 && j == 0) continue;
                int Moverx = col + i, Movery = fil + j;
                while (Moverx >= 0 && Moverx < 8 && Movery >= 0 && Movery < 8)
                {
                    if (tablero[Moverx, Movery] == null)
                    {
                        Console.WriteLine($"{(char)('a' + Moverx)}{Movery + 1}: Vacío");
                    }
                    else if (tablero[Moverx, Movery].Color != color)
                    {
                        Console.WriteLine($"{(char)('a' + Moverx)}{Movery + 1}: {tablero[Moverx, Movery].Color} {tablero[Moverx, Movery].Tipo}");
                        break;
                    }
                    else
                    {
                        break;
                    }
                    Moverx += i;
                    Movery += j;
                }
            }
        }
    }

    //Para utilizar después:
    //if (tablero[fil,col].Color == "Blanco" && tablero[fil,col].Color == "Negro")
       // {
           // Console.WriteLine("Tampoco puedes agregar una pieza acá debido a que es de tu mismo color");
       // }
}
